<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="<?php bloginfo('description'); ?>">
  <title><?php bloginfo('name'); ?></title>
  <!-- Bootstrap core CSS -->
  <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
  <?php wp_head(); ?>
</head>
<body>
  <div class="blog-masthead">
      <nav class="blog-nav">
        <?php
          wp_nav_menu( array(
              'menu'              => 'primary',
              'theme_location'    => 'primary',
              'depth'             => 2,
              'container'         => 'div',
              'container_class'   => 'collapse navbar-collapse',
              'container_id'      => 'bs-example-navbar-collapse-1',
              'menu_class'        => 'nav navbar-nav',
              'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
              'walker'            => new WP_Bootstrap_Navwalker())
          );
      ?>
      </nav>
    </div>
  </div>
  <section class="showcase">
      <h1><?php bloginfo('name'); ?></h1>
      <p>Welcome in Vienna </p>
      <a href="https://www.airpano.com/embed.php?3D=Vienna-Austria" class="btn btn-primary btn-lg" >Click Here</a>
    </div>
  </section>
  <section class="boxes">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-paper-plane" aria-hidden="true"></i>
            <h3>Travel Information Center</h3>
            <p>We look forward to help you plan your trip to Austria. </p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-comments" aria-hidden="true"></i>
            <h3>FREE e-Newsletter</h3>
            <p>Subscribe to our free e-newsletter and receive the latest news, valuable information and special offers for your trip to Austria.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-power-off" aria-hidden="true"></i>
            <h3>Data Protection and Terms of Use</h3>
            <p>On these pages, we inform you in accordance with Art. 13 and 14 GDPR about the processing of your personal data and the rights that you are entitled to as a data subject.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
   <?php get_footer(); ?>