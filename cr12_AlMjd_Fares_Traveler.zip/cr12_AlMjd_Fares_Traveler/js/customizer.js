jQuery( document ).ready( function( $ ){

    $('#customize-info .preview-notice').html('<a class="button button-primary" href="http://kenza.smartcatdev.wpengine.com/frontpage-2/" target="_BLANK">Upgrade to Kenza Pro</a>');
    $('#customize-info .preview-notice').append('<p style="color: #cc0000">The pro version includes unlimited skin colors, a <strong>gorgeous alternate Frontpage</strong>, 200+ Google Font options, Testimonials, FAQ, Services, Team member Widgets & Page Templates, Pricing table widget, and more!</p>');

});